<?php
include("dbcon.php");
// error_reporting(0);

$id=$_REQUEST['del'];

$file=mysqli_query($con,"SELECT ImagePath FROM updates WHERE id='$id'");
while($row=mysqli_fetch_array($file))
{
	$fname=$row['ImagePath'];
}
if($delete=mysqli_query($con,"DELETE FROM updates WHERE id='$id'"))
{
	echo "<script>alert('Updated Deleted!');window.location.href='updates.php';</script>";
	unlink($fname);
}
else
{
	echo "<script>alert('Unable to delete update!');window.location.href='updates.php';</script>";
}
?>