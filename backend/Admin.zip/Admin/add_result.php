<?php
include("dbcon.php");
// error_reporting(0);

$class=$_REQUEST['class'];
$class=trim($class);
$class=mysqli_real_escape_string($con,$class);

$session=$_REQUEST['session'];
$session=trim($session);
$session=mysqli_real_escape_string($con,$session);

$targetfolder = "../uploads/media/pdf/";
 
 $targetfolder = $targetfolder . basename( $_FILES['file']['name']) ;
 
 $ok=1;
$file_name=$_FILES['file']['name'];

$date=$_REQUEST['date'];

$date=mysqli_real_escape_string($con,$date);

$syllabus=$_REQUEST['syllabus'];
$syllabus=trim($syllabus);
$syllabus=mysqli_real_escape_string($con,$syllabus);

if($class=="" || $session=="" ||  $date=="" || $syllabus=="")
{
	echo "<script>alert('Please input all the fields!');window.location.href='results.php';</script>";
}
else
{
	
	$url="../uploads/media/pdf/".$file_name;
 if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
 {

	if($insert=mysqli_query($con,"INSERT INTO `results`(`Class`, `Class_sess` ,`Url` , `date_selected`,`Syllabus`) VALUES ('$class','$session','$url','$date','$syllabus')"))
	{
		echo "<script>alert('Details Added!');window.location.href='results.php';</script>";
	}
	else
	{
		echo "<script>alert('Problem in adding details!');window.location.href='results.php';</script>";
	}}
	else
	{
		echo "<script>alert('".$_FILES['file']['error']."');window.location.href='admissions.php';</script>";		
	}
}
?>