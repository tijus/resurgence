<?php
/*error_reporting(0);
if($con=mysqli_connect("localhost","root","","sc"))
{}
else
{echo "Problem in connecting to Database";}*/
?>

<?php
error_reporting(0);
if($con=mysqli_connect("localhost","somaiyaappadmin","#resurgence2K16","somaiyaappdb"))
{}
else
{echo "Problem in connecting to Database";}
?>